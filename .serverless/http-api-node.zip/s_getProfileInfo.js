
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'direboar',
  applicationName: 'aws-http-api-node-cognito',
  appUid: 'Y3JJ7YY5X0MWRK984d',
  orgUid: 'S77zTlbvdP3hHR6PR5',
  deploymentUid: '3da6b4ab-33e2-4a51-8c0a-d39f3031f2ea',
  serviceName: 'http-api-node',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.1.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'http-api-node-dev-getProfileInfo', timeout: 6 };

try {
  const userHandler = require('./profile.js');
  module.exports.handler = serverlessSDK.handler(userHandler.get, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}